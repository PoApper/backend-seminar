// Make a simple food database server.
// You should follow all the rules wrttien in the description page!
// DON'T reveal your MySQL root password!!!!