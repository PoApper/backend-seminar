// problem1: timer
// Hint: use 'date-utils' or 'moment' library