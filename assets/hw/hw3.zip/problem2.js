// problem2: simple calculator
// hint: parse 'req.url'
// hint: use type conversion