// TODO: implement recursive fibonacci function
// ** test cases **
// 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597
// to test your implementation, pleas print the result when the index is 1 to 12
