// TODO: implement multiplication table
// output format: 1 x 1 = 1
// to test your implementation, please print all the multiplication table
