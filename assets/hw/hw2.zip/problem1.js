// TODO: implement timer using `setInterval()` function

